import express from "express";
import { faqData } from "./faqData.js";
import { findBestMatch } from "./similarity.js";

const app = express();
const PORT = process.env.PORT || 5000;

app.use(express.json());

app.get("/api/health", (req, res) => {
  res.json({
    ok: true,
    message: "FAQ chatbot server is running.",
  });
});

app.get("/api/faqs", (req, res) => {
  res.json({
    faqs: faqData,
  });
});

// Simple calculator
function calculateMath(question) {
  const expression = question
    .replace(/what is/gi, "")
    .replace(/calculate/gi, "")
    .replace(/equals?/gi, "")
    .replace(/=/g, "")
    .replace(/\?/g, "")
    .trim();

  // Allow only numbers and basic math operators
  if (!/^[0-9+\-*/().\s]+$/.test(expression)) {
    return null;
  }

  // Make sure there is actually an operator
  if (!/[+\-*/]/.test(expression)) {
    return null;
  }

  try {
    // Safe because the expression has already been restricted
    // to numbers, spaces, parentheses and math operators.
    const result = Function(`"use strict"; return (${expression})`)();

    if (typeof result === "number" && Number.isFinite(result)) {
      return result;
    }

    return null;
  } catch {
    return null;
  }
}

app.post("/api/ask", (req, res) => {
  const question = String(req.body?.question || "").trim();

  if (!question) {
    return res.status(400).json({
      error: "Question is required.",
    });
  }

  // Check for mathematical questions first
  const mathResult = calculateMath(question);

  if (mathResult !== null) {
    return res.json({
      answer: `The answer is ${mathResult}.`,
      type: "calculation",
    });
  }

  // Otherwise search the FAQ database
  const result = findBestMatch(question, faqData);

  // Don't return a random FAQ when there is no good match
  if (result.score < 0.25) {
    return res.json({
      answer:
        "Sorry, I couldn't find a relevant answer in my FAQ knowledge base. Please try asking another question.",
      type: "fallback",
      score: result.score,
    });
  }

  res.json({
    answer: result.answer,
    matchedQuestion: result.question,
    score: result.score,
    type: "faq",
  });
});

app.listen(PORT, () => {
  console.log(
    `FAQ chatbot server running on http://localhost:${PORT}`
  );
});