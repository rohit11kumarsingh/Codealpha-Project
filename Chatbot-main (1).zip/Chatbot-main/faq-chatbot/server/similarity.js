const STOP=new Set(["a","an","and","are","as","at","be","by","can","do","for","from","how","i","if","in","is","it","me","my","of","on","or","the","this","to","what","when","where","which","who","why","with","you","your"]);

function tokens(text){
  return String(text).toLowerCase().replace(/[^a-z0-9\s]/g," ").split(/\s+/).filter(Boolean).filter(x=>!STOP.has(x)).map(x=>{
    if(x.endsWith("ies")&&x.length>4)return x.slice(0,-3)+"y";
    if(x.endsWith("ing")&&x.length>5)return x.slice(0,-3);
    if(x.endsWith("ed")&&x.length>4)return x.slice(0,-2);
    if(x.endsWith("s")&&x.length>3)return x.slice(0,-1);
    return x;
  });
}

function tf(ts){const m=new Map();for(const t of ts)m.set(t,(m.get(t)||0)+1);return m}
function idf(docs){const df=new Map();for(const d of docs)for(const t of new Set(d))df.set(t,(df.get(t)||0)+1);const out=new Map();for(const [t,n] of df)out.set(t,Math.log((docs.length+1)/(n+1))+1);return out}
function vector(ts,weights){const m=tf(ts),v=new Map();for(const [t,n] of m)if(weights.has(t))v.set(t,n/ts.length*weights.get(t));return v}
function cosine(a,b){let dot=0,aa=0,bb=0;for(const [t,x] of a){dot+=x*(b.get(t)||0);aa+=x*x}for(const x of b.values())bb+=x*x;return aa&&bb?dot/(Math.sqrt(aa)*Math.sqrt(bb)):0}

export function findBestMatch(question,faqs){
  const q=tokens(question), docs=faqs.map(f=>tokens(f.question)), weights=idf([q,...docs]), qv=vector(q,weights);
  let best={...faqs[0],score:0};
  faqs.forEach((f,i)=>{const score=cosine(qv,vector(docs[i],weights));if(score>best.score)best={...f,score}});
  return best;
}