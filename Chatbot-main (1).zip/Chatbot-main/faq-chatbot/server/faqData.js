export const faqData=[
{id:1,question:"What is this product?",answer:"This product is an FAQ chatbot that understands a user's question and finds the most similar question from the FAQ knowledge base."},
{id:2,question:"How do I reset my password?",answer:"Open the login page, select Forgot password, enter your registered email address, and follow the password reset instructions."},
{id:3,question:"How can I contact support?",answer:"You can contact support through the support section of the website or by sending a message to the support team."},
{id:4,question:"How do I create an account?",answer:"Click Sign Up, enter your details, create a password, and complete the verification step."},
{id:5,question:"How do I change my email address?",answer:"Open Account Settings, update your email address, and complete any requested verification."},
{id:6,question:"What should I do if I forgot my username?",answer:"Use the account recovery option or contact support with the email address associated with your account."},
{id:7,question:"How do I update my profile?",answer:"Go to Account Settings, edit your profile information, and save your changes."},
{id:8,question:"Is my information secure?",answer:"The application should protect user information with appropriate authentication, access controls, and secure data handling."},
{id:9,question:"How do I delete my account?",answer:"Open Account Settings and look for the account deletion option. If it is unavailable, contact support."},
{id:10,question:"Why is my account not working?",answer:"Check your internet connection and login details first. If the problem continues, use account recovery or contact support."}
];