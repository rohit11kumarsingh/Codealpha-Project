import { useState } from "react";
import "./styles.css";

const suggestions = [
  "How do I reset my password?",
  "How can I contact support?",
  "How do I create an account?",
  "Is my information secure?",
];

function App() {
  const [question, setQuestion] = useState("");
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const askQuestion = async (text = question) => {
    const q = text.trim();

    if (!q || loading) return;

    setMessages((prev) => [
      ...prev,
      {
        type: "user",
        text: q,
      },
    ]);

    setQuestion("");
    setLoading(true);

    try {
      const response = await fetch("/api/ask", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          question: q,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Something went wrong");
      }

      setMessages((prev) => [
        ...prev,
        {
          type: "bot",
          text: data.answer,
          matchedQuestion: data.matchedQuestion,
          score: data.score,
          calculation: data.type === "calculation",
        },
      ]);
    } catch (error) {
      setMessages((prev) => [
        ...prev,
        {
          type: "bot",
          text: "Sorry, I couldn't connect to the server.",
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    askQuestion();
  };

  return (
    <div className="gemini-app">

      {/* Sidebar */}
      <aside className={`sidebar ${sidebarOpen ? "open" : ""}`}>
        <div className="sidebar-top">
          <button
            className="menu-btn"
            onClick={() => setSidebarOpen(false)}
          >
            ☰
          </button>

          <div className="logo-small">
            ✦
          </div>
        </div>

        <button
          className="new-chat"
          onClick={() => setMessages([])}
        >
          <span>＋</span>
          New chat
        </button>

        <div className="sidebar-section">
          <p>FAQ Assistant</p>

          <div className="history-item">
            <span>💬</span>
            FAQ Chat
          </div>
        </div>

        <div className="sidebar-bottom">
          <div className="sidebar-item">
            ⚙️ Settings
          </div>

          <div className="sidebar-item">
            ❓ Help
          </div>
        </div>
      </aside>

      {/* Main */}
      <main className="main-content">

        {/* Header */}
        <header className="topbar">
          <button
            className="mobile-menu"
            onClick={() => setSidebarOpen(true)}
          >
            ☰
          </button>

          <div className="brand">
            <span className="brand-icon">✦</span>
            <span>FAQ Assistant</span>
          </div>

          <div className="profile">
            S
          </div>
        </header>

        {/* Chat */}
        <div className="chat-area">

          {messages.length === 0 ? (
            <div className="welcome">

              <div className="welcome-icon">
                ✦
              </div>

              <h1>
                Hello, <span>there</span>
              </h1>

              <h2>
                How can I help you?
              </h2>

              <p>
                Ask me anything about the product, account or support.
              </p>

              <div className="suggestions">
                {suggestions.map((item) => (
                  <button
                    key={item}
                    onClick={() => askQuestion(item)}
                  >
                    <span>✦</span>
                    {item}
                  </button>
                ))}
              </div>

            </div>
          ) : (
            <div className="conversation">

              {messages.map((message, index) => (
                <div
                  key={index}
                  className={`message ${
                    message.type === "user"
                      ? "user-message"
                      : "bot-message"
                  }`}
                >

                  {message.type === "bot" && (
                    <div className="bot-avatar">
                      ✦
                    </div>
                  )}

                  <div className="message-content">

                    <div className="message-name">
                      {message.type === "user"
                        ? "You"
                        : "FAQ Assistant"}
                    </div>

                    <div className="message-text">
                      {message.text}
                    </div>

                    {message.matchedQuestion && (
                      <div className="match-info">
                        Matched FAQ: {message.matchedQuestion}
                        <br />
                        Similarity:{" "}
                        {(message.score * 100).toFixed(1)}%
                      </div>
                    )}

                  </div>
                </div>
              ))}

              {loading && (
                <div className="message bot-message">
                  <div className="bot-avatar">
                    ✦
                  </div>

                  <div className="message-content">
                    <div className="message-name">
                      FAQ Assistant
                    </div>

                    <div className="typing">
                      <span></span>
                      <span></span>
                      <span></span>
                    </div>
                  </div>
                </div>
              )}

            </div>
          )}

        </div>

        {/* Input */}
        <div className="input-wrapper">

          <form
            className="chat-input"
            onSubmit={handleSubmit}
          >

            <button
              type="button"
              className="input-icon"
            >
              ＋
            </button>

            <input
              type="text"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="Ask FAQ Assistant"
            />

            <button
              type="button"
              className="input-icon"
            >
              🎤
            </button>

            <button
              type="submit"
              className="send-btn"
              disabled={!question.trim() || loading}
            >
              ↑
            </button>

          </form>

          <p className="disclaimer">
            FAQ Assistant can make mistakes. Check important information.
          </p>

        </div>

      </main>
    </div>
  );
}

export default App;